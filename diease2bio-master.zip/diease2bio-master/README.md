# diease2bio
* 属性对应关系



|               数据表               |            实体类             | 前端 |
| :--------------------------------: | :---------------------------: | :--: |
|       ICD-11 classification        |            ICD_10             |  a   |
|          TissuePubMed_ID           |           PUBMED_ID           |  a   |
|      Interaction gene symbol       |          INTERACTION          |  a   |
|        Expression direction        |      EXPRESSIONDIRECTION      |  a   |
|        Experimental method         |        DETECTIONMETHOD        |  a   |
| Experimental method classification | DETECTIONMETHODCLASSIFICATION |  a   |
|             Throughput             |      DETECTIONTHROUGHPUT      |  a   |





