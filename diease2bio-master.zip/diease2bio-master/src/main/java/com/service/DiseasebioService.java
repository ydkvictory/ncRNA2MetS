package com.service;

import com.bean.Diseasebio;
import com.bean.SubData;
import com.dto.SearchResultVO;
import com.dto.SearchVO;

import java.util.List;

public interface DiseasebioService {

    /**
     * 获取目录信息
     * @return
     */
    public String getAllDir();

    /**
     * 通过Name获取数据
     * @return
     */
    public List<Diseasebio> getDisBioByName(String id);

    public Diseasebio queryById(Long id);

    public List<SearchResultVO> search(SearchVO searchVO);

    public void save(SubData subData);
}
