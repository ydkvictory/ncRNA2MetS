package com.service.impl;

import com.alibaba.fastjson.JSON;
import com.bean.ChildDir;
import com.bean.Directory;
import com.bean.Diseasebio;
import com.bean.SubData;
import com.dao.DiseasebioDAO;
import com.dto.SearchResultVO;
import com.dto.SearchVO;
import com.service.DiseasebioService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class DiseasebioServiceImpl implements DiseasebioService {

    @Autowired
    private DiseasebioDAO diseasebioDAO;

    public String getAllDir() {
        List<Directory> directories = new ArrayList<Directory>();
        Directory directory1 = new Directory();
        Directory directory2 = new Directory();
        Directory directory3 = new Directory();
        Directory directory4 = new Directory();
        Directory directory5 = new Directory();
        directory1.setText("Disease");
        directory1.setId("Disease");
        directory2.setText("MicroRNA");
        directory2.setId("microRNA");
        directory3.setText("LncRNA");
        directory3.setId("lncRNA");
        directory4.setText("Tissue");
        directory4.setId("Tissue");
        directory5.setText("Experiment");
        directory5.setId("Experiment");

        List<String> disNames = diseasebioDAO.queryAllDiseaseName();
        List<String> micrna = diseasebioDAO.queryBymicroRNA();
        List<String> incrna = diseasebioDAO.queryBylncRNA();
        List<String> iissue = diseasebioDAO.queryByTissue();
        List<String> experiment = diseasebioDAO.queryByExperiment();
        List<ChildDir> childDirs1 = new ArrayList<>();
        List<ChildDir> childDirs2 = new ArrayList<>();
        List<ChildDir> childDirs3 = new ArrayList<>();
        List<ChildDir> childDirs4 = new ArrayList<>();
        List<ChildDir> childDirs5 = new ArrayList<>();
        disNames.forEach(t-> {
            ChildDir childDir = new ChildDir();
            StringBuffer buffer = new StringBuffer("Disease!");
            childDir.setText(t);
            childDir.setId(buffer.append(t).toString());
            childDirs1.add(childDir);
        });
        micrna.forEach(t-> {
            ChildDir childDir = new ChildDir();
            StringBuffer buffer = new StringBuffer("MicroRNA!");
            childDir.setText(t);
            childDir.setId(buffer.append(t).toString());
            childDirs2.add(childDir);
        });
        incrna.forEach(t-> {
            ChildDir childDir = new ChildDir();
            StringBuffer buffer = new StringBuffer("LncRNA!");
            childDir.setText(t);
            childDir.setId(buffer.append(t).toString());
            childDirs3.add(childDir);
        });
        iissue.forEach(t-> {
            ChildDir childDir = new ChildDir();
            StringBuffer buffer = new StringBuffer("Tissue!");
            childDir.setText(t);
            childDir.setId(buffer.append(t).toString());
            childDirs4.add(childDir);
        });
        experiment.forEach(t-> {
            ChildDir childDir = new ChildDir();
            StringBuffer buffer = new StringBuffer("Experiment!");
            childDir.setText(t);
            childDir.setId(buffer.append(t).toString());
            childDirs5.add(childDir);
        });
        directory1.setChildren(childDirs1);
        directory2.setChildren(childDirs2);
        directory3.setChildren(childDirs3);
        directory4.setChildren(childDirs4);
        directory5.setChildren(childDirs5);
        directories.add(directory1);
        directories.add(directory2);
        directories.add(directory3);
        directories.add(directory4);
        directories.add(directory5);
        String s = JSON.toJSONString(directories);
        return s;
    }

    @Override
    public List<Diseasebio> getDisBioByName(String id) {
        List<Diseasebio> dieasebios = new ArrayList<>();
        String[] split = id.split("!");
        if ("Disease".equals(split[0].toString())){
            dieasebios = diseasebioDAO.queryByDisName(split[1]);
        }
        else if("Tissue".equals(split[0].toString()) ){
            dieasebios = diseasebioDAO.queryByTissue2(split[1]);
        }
        else if("Experiment".equals(split[0].toString()) ){
            dieasebios = diseasebioDAO.queryByExperiment2(split[1]);
        }
        else {
            dieasebios = diseasebioDAO.queryByRNAName(split[1],split[0]);
        }
        log.info("+++++++++++++++++++++++++"+dieasebios.size());

        return dieasebios;
    }

    @Override
    public Diseasebio queryById(Long id) {
        Diseasebio diseasebio = diseasebioDAO.queryById(id);
        return diseasebio;
    }

    @Override
    public List<SearchResultVO> search(SearchVO searchVO) {
        List<SearchResultVO> searchResultVOS = new ArrayList<>();
        List<Diseasebio> diseasebios = new ArrayList<>();
        if("fuzzy".equals(searchVO.getSearchType())){
            diseasebios = diseasebioDAO.queryBySearchVOLike(searchVO);
        }else {
            diseasebios = diseasebioDAO.queryBySearchVO(searchVO);
        }
        diseasebios.forEach(t->{
            SearchResultVO searchResultVO = new SearchResultVO();
            searchResultVO.setId(Long.toString(t.getID()));
            searchResultVO.setDetectionthroughput(t.getDETECTIONTHROUGHPUT());
            searchResultVO.setDisease(t.getDISEASE());
            searchResultVO.setPubmed_id(t.getPUBMED_ID());
            searchResultVO.setRna_category(t.getRNA_CATEGORY());
            searchResultVO.setRna_symbol(t.getRNA_SYMBOL());
            searchResultVO.setSpecies(t.getSPECIES());
            searchResultVOS.add(searchResultVO);
        });
        return searchResultVOS;
    }

    @Override
    public void save(SubData subData){
        diseasebioDAO.save(subData);
    }

}
