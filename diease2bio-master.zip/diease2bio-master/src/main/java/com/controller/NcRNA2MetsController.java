package com.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.util.TypeUtils;
import com.bean.Diseasebio;
import com.bean.SubData;
import com.dao.DiseasebioDAO;
import com.dto.SearchResultVO;
import com.dto.SearchVO;
import com.service.DiseasebioService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;


@Slf4j
@Controller
@RequestMapping("/ncRNA2MetS")
public class NcRNA2MetsController {

    @Autowired
    private DiseasebioDAO diseasebioDAO;

    @Autowired
    private DiseasebioService diseasebioService;

    @RequestMapping(value = "/update")
    @ResponseBody
    public String updatePassword() {
        System.out.println("update");
        List<String> query = diseasebioDAO.query();
        Set<String> set = new HashSet<>();
        query.forEach(t->{
            String[] split = t.split(";");
            for(int i = 0;i<split.length;i++) {
                set.add(split[i]);
            }
        });
        set.forEach(t->{
            System.out.println(t);
        });
        return null;
    }

    @RequestMapping(value = "/species-tree")
    @ResponseBody
    public String speciestree() {
        System.out.println("species-tree");
//        return "[{\"text\":\"Disease\",\"id\":\"Disease\",\"state\":\"closed\"},{\"text\":\"MicroRNA\",\"id\":\"microRNA\",\"state\":\"closed\"},{\"text\":\"Metabolite\",\"id\":\"metabolite\",\"state\":\"closed\"},{\"text\":\"Small molecule & Drug\",\"id\":\"drug\",\"state\":\"closed\"}]";
//        return "[{\"text\":\"Disease\",\"id\":\"Disease\",\"state\":\"closed\",\"children\":[{\"text\":\"Acne\",\"id\":\"Disease!Acne\",\"state\":\"open\"},{\"text\":\"Acrodermatitis enterop...\",\"id\":\"Disease!Acrodermatitis enteropathica\",\"state\":\"open\"}]},{\"text\":\"MicroRNA\",\"id\":\"microRNA\",\"state\":\"closed\"},{\"text\":\"Metabolite\",\"id\":\"metabolite\",\"state\":\"closed\"},{\"text\":\"Small molecule & Drug\",\"id\":\"drug\",\"state\":\"closed\"}]";
        return diseasebioService.getAllDir();
    }

    @RequestMapping(value = "/species-node",method = RequestMethod.GET)
    @ResponseBody
    public String speciestreea(String id, String filter) {
        System.out.println("species-tree-id");
//        RNA_Category=lncRNA&Species=&Detection=
//        RNA_Category%3DlncRNA%26Species%3D%26Detection%3D
        System.out.println(id);
        System.out.println(filter);
//        return "[{\"ID\":2472,\"RNA_CATEGORY\":\"drug\",\"SPECIES\":\"Homo sapiens\",\"RNA_SYMBOL\":\"Tazarotene\",\"BIOID\":\"5381\",\"DISEASE\":\"Acne\",\"DISEASE_ONTOLOGY\":\"DOID:6543\",\"ICD_10\":\"L70;L73\",\"TISSUE\":\"blood\",\"PUBMED_ID\":\"23456673\",\"INTERACTION\":\"-\",\"EXPRESSIONDIRECTION\":\"-\",\"DETECTIONMETHOD\":\"high-performance liquid chromatography-tandem mass spectrometry\",\"DETECTIONMETHODCLASSIFICATION\":\"spectrum\",\"DETECTIONTHROUGHPUT\":\"High-throughput\",\"DESCRIPTION\":\"Tazarotene, a retinoid pro-drug, is available in gel, cream and foam for the topical treatment of acne vulgaris.\",\"REFERENCETITLE\":\"Tazarotene foam versus tazarotene gel: a randomized relative bioavailability study in acne vulgaris\",\"YEAR\":\"2013\"}]";
        TypeUtils.compatibleWithJavaBean = true;
        List<Diseasebio> disBioByName = diseasebioService.getDisBioByName(id);
        HashMap<String,String> searchFilter = new HashMap<>();
        if(filter != null && filter.length()>0){
            String[] filters = filter.split("&");
            for(int i=0;i<filters.length;i++){
                String[] fs = filters[i].split("=");
                searchFilter.put(fs[0],fs.length==1?null:fs[1]);
            }
            String RNA_CATEGORY = searchFilter.get("RNA_Category");
            String SPECIES = searchFilter.get("Species");
            String DETECTIONTHROUGHPUT = searchFilter.get("Detection");

            for(int i=0;i<disBioByName.size();i++){
                Diseasebio diseasebio = disBioByName.get(i);
                if(RNA_CATEGORY!=null && !RNA_CATEGORY.equals(diseasebio.getRNA_CATEGORY())){
                    disBioByName.remove(i--);
                    continue;
                }
                if(SPECIES!=null && !SPECIES.equals(diseasebio.getSPECIES())){
                    disBioByName.remove(i--);
                    continue;
                }
                if(DETECTIONTHROUGHPUT!=null && !DETECTIONTHROUGHPUT.equals(diseasebio.getDETECTIONTHROUGHPUT())){
                    disBioByName.remove(i--);
                    continue;
                }
            }
        }
        return JSON.toJSONString(disBioByName);
    }

    @RequestMapping(value = "/do-search",method = RequestMethod.POST)
//    @ResponseBody
    public String search(HttpServletRequest request, HttpSession session, SearchVO searchVO , Model model) {
        ModelAndView mav = new ModelAndView("do-search");
        List<SearchResultVO> list = diseasebioService.search(searchVO);

//        list.add(new SearchResultVO("id","detectionthroughput","rna_category","species","rna_symbol","disease","pubmed_id"));
//        list.add(new SearchResultVO("id1","detectionthroughput1","rna_category1","species1","rna_symbol","disease","pubmed_id"));
//        list.add(new SearchResultVO("id2","detectionthroughput1","rna_category1","species1","rna_symbol","disease","pubmed_id"));
//        list.add(new SearchResultVO("id3","detectionthroughput1","rna_category1","species1","rna_symbol","disease","pubmed_id"));
//        list.add(new SearchResultVO("id4","detectionthroughput1","rna_category1","species1","rna_symbol","disease","pubmed_id"));

        session.setAttribute("searchVO",searchVO);
//        mav.addObject("list",list);
        model.addAttribute("list",list);
//        request.setAttribute("list",list);
        System.out.println("do-search");
        System.out.println(searchVO);
        return "do-search";
    }

    //参考
    //https://blog.csdn.net/qq_34309663/article/details/83090298

    @RequestMapping("/download-search-result")
    public void down1(HttpServletRequest req, HttpServletResponse response, HttpSession session) throws Exception {
        System.out.println("第三种下载");
        BufferedOutputStream bos = null;

        //设置文件输出类型
        response.setHeader("Content-disposition", "attachment; filename="
                + new String("result.txt".getBytes("utf-8"), "ISO8859-1"));
        response.setContentType("text/plain");

        //输出流
        bos = new BufferedOutputStream(response.getOutputStream());
        bos.write(getStr4DownResult((SearchVO) session.getAttribute("searchVO")).getBytes(StandardCharsets.UTF_8));
        //关闭流
        bos.close();
    }

    private String getStr4DownResult(SearchVO searchVO){
        String res = "#\tRNA_Category\tSpecies\tRNA_symbol\tDisease\tPubmed_Id"+System.getProperty("line.separator");

//        ArrayList<SearchResultVO> list = new ArrayList<>();
//        list.add(new SearchResultVO("id","detectionthroughput","rna_category","species","rna_symbol","disease","pubmed_id"));
//        list.add(new SearchResultVO("id2","detectionthroughput1","rna_category1","species1","rna_symbol","disease","pubmed_id"));
//        list.add(new SearchResultVO("id3","detectionthroughput1","rna_category1","species1","rna_symbol","disease","pubmed_id"));
//        list.add(new SearchResultVO("id4","detectionthroughput1","rna_category1","species1","rna_symbol","disease","pubmed_id"));

//        ArrayList<SearchResultVO> searchResult = new ArrayList<>();
        List<SearchResultVO> searchResult = diseasebioService.search(searchVO);
        for(int i=0;i<searchResult.size();i++){
            SearchResultVO vo = searchResult.get(i);
            res += (i+1) +
                    "\t"
                    +vo.getRna_category()
                    +"\t"
                    +vo.getSpecies()
                    +"\t"
                    +vo.getRna_symbol()
                    +"\t"
                    +vo.getDisease()
                    +"\t"
                    +vo.getPubmed_id()
                    +System.getProperty("line.separator");
        }
        return res;
    }

    @RequestMapping("/downloadAllData")
    public void downloadExcelFile(HttpServletRequest request, HttpServletResponse response) {
        // 1: 找到excel文件
        String storePath = request.getSession().getServletContext().getRealPath("/") + "file/";
        System.out.println(storePath);
        String fileName = "ncRNA2MetS.xlsx";

        File file = new File(storePath + fileName);
        if (!file.exists()) {
            throw new RuntimeException("file do not exist");
        }
        InputStream inputStream = null;
        ServletOutputStream servletOutputStream = null;
        // 重置response
        response.reset();
        //设置http头信息的内容
        response.setCharacterEncoding("utf-8");
        response.setContentType("application/vnd.ms-excel");
        response.addHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\"");
        int fileLength = (int) file.length();
        response.setContentLength(fileLength);

        try {
            if (fileLength != 0) {
                inputStream = new FileInputStream(file);
                byte[] buf = new byte[4096];
                // 创建输出流
                servletOutputStream = response.getOutputStream();
                int readLength;
                // 读取文件内容并输出到response的输出流中
                while ((readLength = inputStream.read(buf)) != -1) {
                    servletOutputStream.write(buf, 0, readLength);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("download file error");
        } finally {
            try {
                // 关闭ServletOutputStream
                if (servletOutputStream != null) {
                    servletOutputStream.flush();
                    servletOutputStream.close();
                }
                // 关闭InputStream
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }



    private ArrayList<SearchResultVO> getSearchResult(SearchVO searchVO){
        ArrayList<SearchResultVO> res = null;
        return res;
    }

        @RequestMapping(value = "/filter-search")
    @ResponseBody
    public String filterSearch( HttpSession session ,SearchVO search ) {

        System.out.println("filterSearch");
        System.out.println(search);

        SearchVO searchVO = (SearchVO)session.getAttribute("searchVO");
        searchVO.setCategory(search.getCategory());
        searchVO.setSpecies(search.getSpecies());
        searchVO.setDetection(search.getDetection());

//        ArrayList<SearchResultVO> list = new ArrayList<>();
//        list.add(new SearchResultVO("id","detectionthroughput","rna_category","species","rna_symbol","disease","pubmed_id"));
//        list.add(new SearchResultVO("id2","detectionthroughput1","rna_category1","species1","rna_symbol","disease","pubmed_id"));
//        list.add(new SearchResultVO("id3","detectionthroughput1","rna_category1","species1","rna_symbol","disease","pubmed_id"));
//        list.add(new SearchResultVO("id4","detectionthroughput1","rna_category1","species1","rna_symbol","disease","pubmed_id"));
            List<SearchResultVO> list = diseasebioService.search(searchVO);

        String jsonStr = JSON.toJSONString(list);
        return jsonStr;
    }

    @RequestMapping(value = "/browseDetails")
    public ModelAndView browseDetails(Long id) {
        ModelAndView mav = new ModelAndView("browseDetails");
        System.out.println("browseDetails");
        Diseasebio detail = diseasebioService.queryById(id);
        mav.addObject("detail",detail);
        return mav;
    }


}

//    create table web_submit(
//        id int,
//        author_name  varchar(1000),
//    email varchar(1000),
//    title varchar(1000),
//    pubmed_id varchar(1000),
//    rna_category varchar(1000),
//    rna_symbol varchar(1000),
//    disease varchar(1000),
//    tissue varchar(1000),
//    species varchar(1000),
//    interaction varchar(1000),
//    detection_method varchar(1000),
//    description varchar(1000)
//)
//        CREATE TABLE `hlg`.`web_submit`  (
//        `id` int(11) NOT NULL AUTO_INCREMENT,
//        `author_name` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `email` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `title` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `pubmed_id` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `rna_category` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `rna_symbol` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `disease` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `tissue` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `species` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `interaction` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `detection_method` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `description` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        PRIMARY KEY (`id`) USING BTREE
//        ) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;