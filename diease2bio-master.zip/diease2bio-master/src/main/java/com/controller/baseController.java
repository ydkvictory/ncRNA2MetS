package com.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.util.TypeUtils;
import com.bean.Diseasebio;
import com.bean.SubData;
import com.dao.DiseasebioDAO;
import com.dto.SearchResultVO;
import com.dto.SearchVO;
import com.service.DiseasebioService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;


@Slf4j
@Controller
@RequestMapping("/")
public class baseController {

    @Autowired
    private DiseasebioDAO diseasebioDAO;

    @Autowired
    private DiseasebioService diseasebioService;


    @RequestMapping(value = "/save")
    public String  save(SubData subData) {
        ModelAndView mav = new ModelAndView("submit");
        diseasebioService.save(subData);
        return  "forward:/index.html";
    }

}

//    create table web_submit(
//        id int,
//        author_name  varchar(1000),
//    email varchar(1000),
//    title varchar(1000),
//    pubmed_id varchar(1000),
//    rna_category varchar(1000),
//    rna_symbol varchar(1000),
//    disease varchar(1000),
//    tissue varchar(1000),
//    species varchar(1000),
//    interaction varchar(1000),
//    detection_method varchar(1000),
//    description varchar(1000)
//)
//        CREATE TABLE `hlg`.`web_submit`  (
//        `id` int(11) NOT NULL AUTO_INCREMENT,
//        `author_name` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `email` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `title` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `pubmed_id` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `rna_category` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `rna_symbol` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `disease` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `tissue` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `species` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `interaction` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `detection_method` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        `description` varchar(1000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
//        PRIMARY KEY (`id`) USING BTREE
//        ) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;