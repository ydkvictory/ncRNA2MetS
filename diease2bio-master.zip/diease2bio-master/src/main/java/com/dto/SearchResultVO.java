package com.dto;

import lombok.Data;

@Data
public class SearchResultVO {
    private String id;
    private String detectionthroughput;
    private String rna_category;
    private String species;
    private String rna_symbol;
    private String disease;
    private String pubmed_id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDetectionthroughput() {
        return detectionthroughput;
    }

    public void setDetectionthroughput(String detectionthroughput) {
        this.detectionthroughput = detectionthroughput;
    }

    public String getRna_category() {
        return rna_category;
    }

    public void setRna_category(String rna_category) {
        this.rna_category = rna_category;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public String getRna_symbol() {
        return rna_symbol;
    }

    public void setRna_symbol(String rna_symbol) {
        this.rna_symbol = rna_symbol;
    }

    public String getDisease() {
        return disease;
    }

    public void setDisease(String disease) {
        this.disease = disease;
    }

    public String getPubmed_id() {
        return pubmed_id;
    }

    public void setPubmed_id(String pubmed_id) {
        this.pubmed_id = pubmed_id;
    }

    public SearchResultVO(){}

    public SearchResultVO(String id, String detectionthroughput, String rna_category, String species, String rna_symbol, String disease, String pubmed_id) {
        this.id = id;
        this.detectionthroughput = detectionthroughput;
        this.rna_category = rna_category;
        this.species = species;
        this.rna_symbol = rna_symbol;
        this.disease = disease;
        this.pubmed_id = pubmed_id;
    }
}
