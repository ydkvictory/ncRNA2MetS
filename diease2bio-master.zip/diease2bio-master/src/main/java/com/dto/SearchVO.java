package com.dto;

import lombok.Data;


@Data
public class SearchVO {
    private String searchType;
    private String disease;
    private String smolecule;
    private String smoleculeType;
    private String[] detectionType;

    private String category;
    private String species;
    private String detection;

    public SearchVO() {}

    public SearchVO(String searchType, String disease, String smolecule, String[] detectionType) {
        this.searchType = searchType;
        this.disease = disease;
        this.smolecule = smolecule;
        this.detectionType = detectionType;
    }



}
