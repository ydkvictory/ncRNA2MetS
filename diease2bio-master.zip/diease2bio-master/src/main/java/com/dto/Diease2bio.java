package com.dto;

import lombok.Data;

@Data
public class Diease2bio {
    private int id;
    private String category;
    private String species;
    private String biomolecule_name;
    private String biomolecule_id;
    private String disease_name;
    private String disease_ontology;
    private String icd_11_classification;
    private String tissue;
    private String pubMed_id;
    private String interaction_gene_symbol;
    private String expression_direction;
    private String experimental_method;
    private String experimental_method_classification;
    private String throughput;
    private String description;
    private String reference_title;
    private String year;

    public Diease2bio() {
    }

    public Diease2bio(int id, String category, String species, String biomolecule_name, String biomolecule_id, String disease_name, String disease_ontology, String icd_11_classification, String tissue, String pubMed_id, String interaction_gene_symbol, String expression_direction, String experimental_method, String experimental_method_classification, String throughput, String description, String reference_title, String year) {
        this.id = id;
        this.category = category;
        this.species = species;
        this.biomolecule_name = biomolecule_name;
        this.biomolecule_id = biomolecule_id;
        this.disease_name = disease_name;
        this.disease_ontology = disease_ontology;
        this.icd_11_classification = icd_11_classification;
        this.tissue = tissue;
        this.pubMed_id = pubMed_id;
        this.interaction_gene_symbol = interaction_gene_symbol;
        this.expression_direction = expression_direction;
        this.experimental_method = experimental_method;
        this.experimental_method_classification = experimental_method_classification;
        this.throughput = throughput;
        this.description = description;
        this.reference_title = reference_title;
        this.year = year;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public String getBiomolecule_name() {
        return biomolecule_name;
    }

    public void setBiomolecule_name(String biomolecule_name) {
        this.biomolecule_name = biomolecule_name;
    }

    public String getBiomolecule_id() {
        return biomolecule_id;
    }

    public void setBiomolecule_id(String biomolecule_id) {
        this.biomolecule_id = biomolecule_id;
    }

    public String getDisease_name() {
        return disease_name;
    }

    public void setDisease_name(String disease_name) {
        this.disease_name = disease_name;
    }

    public String getDisease_ontology() {
        return disease_ontology;
    }

    public void setDisease_ontology(String disease_ontology) {
        this.disease_ontology = disease_ontology;
    }

    public String getIcd_11_classification() {
        return icd_11_classification;
    }

    public void setIcd_11_classification(String icd_11_classification) {
        this.icd_11_classification = icd_11_classification;
    }

    public String getTissue() {
        return tissue;
    }

    public void setTissue(String tissue) {
        this.tissue = tissue;
    }

    public String getPubMed_id() {
        return pubMed_id;
    }

    public void setPubMed_id(String pubMed_id) {
        this.pubMed_id = pubMed_id;
    }

    public String getInteraction_gene_symbol() {
        return interaction_gene_symbol;
    }

    public void setInteraction_gene_symbol(String interaction_gene_symbol) {
        this.interaction_gene_symbol = interaction_gene_symbol;
    }

    public String getExpression_direction() {
        return expression_direction;
    }

    public void setExpression_direction(String expression_direction) {
        this.expression_direction = expression_direction;
    }

    public String getExperimental_method() {
        return experimental_method;
    }

    public void setExperimental_method(String experimental_method) {
        this.experimental_method = experimental_method;
    }

    public String getExperimental_method_classification() {
        return experimental_method_classification;
    }

    public void setExperimental_method_classification(String experimental_method_classification) {
        this.experimental_method_classification = experimental_method_classification;
    }

    public String getThroughput() {
        return throughput;
    }

    public void setThroughput(String throughput) {
        this.throughput = throughput;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getReference_title() {
        return reference_title;
    }

    public void setReference_title(String reference_title) {
        this.reference_title = reference_title;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }
}
