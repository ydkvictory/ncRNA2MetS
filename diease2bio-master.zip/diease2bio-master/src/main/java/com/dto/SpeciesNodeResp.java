package com.dto;

import lombok.Data;

@Data
public class SpeciesNodeResp {

    private Long ID;

    private String RNA_CATEGORY;

    private String SPECIES;

    private String RNA_SYMBOL;

    private String BIOID;

    private String DISEASE;

    private String DISEASE_ONTOLOGY;

    private String ICD_10;

    private String TISSUE;

    private String PUBMED_ID;

    private String INTERACTION;

    private String EXPRESSIONDIRECTION;

    private String DETECTIONMETHOD;

    private String DETECTIONMETHODCLASSIFICATION;

    private String DETECTIONTHROUGHPUT;

    private String DESCRIPTION;

    private String REFERENCETITLE;

    private String YEAR;
}
