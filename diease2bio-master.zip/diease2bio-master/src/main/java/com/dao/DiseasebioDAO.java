package com.dao;


import com.bean.Diseasebio;
import com.bean.SubData;
import com.dto.SearchVO;
import org.apache.ibatis.annotations.Param;

import javax.annotation.Resource;
import java.util.List;
@Resource
public interface DiseasebioDAO {


    public void insert();

    public List<String> queryAllDiseaseName();

    public List<String> queryBymicroRNA();

    public List<String> queryBylncRNA();
    public List<String> queryByTissue();
    public List<String> queryByExperiment();

    public List<Diseasebio> queryByRNAName(@Param("biomoleculeName")String biomoleculeName,@Param("category")String category);

    public List<Diseasebio> queryByDisName(String disName);
    public List<Diseasebio> queryByTissue2(String Tissue);
    public List<Diseasebio> queryByExperiment2(String Experiment);

    public Diseasebio queryById(Long id);

    public List<Diseasebio> queryBySearchVO(@Param("searchVO") SearchVO searchVO);

    public List<Diseasebio> queryBySearchVOLike(@Param("searchVO") SearchVO searchVO);

    public List<String> query();

    public void save(@Param("sub") SubData subData);
}
