package com.bean;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class Directory implements Serializable {

    private String id;

    private String text;

    private String state = "closed";

    private List<ChildDir> children;
}
