package com.bean;

import lombok.Data;

@Data
public class ChildDir {

    private String id;

    private String text;

    private String state = "open";
}
