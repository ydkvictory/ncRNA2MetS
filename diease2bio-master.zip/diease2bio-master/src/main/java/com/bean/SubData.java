package com.bean;

import lombok.Data;

@Data
public class SubData {

    private String AuthorName;

    private String Email;

    private String Title;

    private String Pubmed_Id;

    private String RNA_Category;

    private String RNA_symbol;

    private String Disease;

    private String Tissue;

    private String Species;

    private String Interaction;

    private String DetectionMethod;

    private String Description;


}
