/*
Navicat MySQL Data Transfer

Source Server         : 101.200.55.245
Source Server Version : 50723
Source Host           : 101.200.55.245:3306
Source Database       : hlg

Target Server Type    : MYSQL
Target Server Version : 50723
File Encoding         : 65001

Date: 2019-08-30 11:03:25
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `web_submit`
-- ----------------------------
DROP TABLE IF EXISTS `web_submit`;
CREATE TABLE `web_submit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author_name` varchar(1000) DEFAULT NULL,
  `email` varchar(1000) DEFAULT NULL,
  `title` varchar(1000) DEFAULT NULL,
  `pubmed_id` varchar(1000) DEFAULT NULL,
  `rna_category` varchar(1000) DEFAULT NULL,
  `rna_symbol` varchar(1000) DEFAULT NULL,
  `disease` varchar(1000) DEFAULT NULL,
  `tissue` varchar(1000) DEFAULT NULL,
  `species` varchar(1000) DEFAULT NULL,
  `interaction` varchar(1000) DEFAULT NULL,
  `detection_method` varchar(1000) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of web_submit
-- ----------------------------
INSERT INTO `web_submit` VALUES ('1', '1', 'suim_cn@163.com', '1', '1', 'microRNA', '1', '1', '1', '1', '1', '1', '11');
INSERT INTO `web_submit` VALUES ('2', '2', 'suim_cn@163.com', '2', '3', 'microRNA', '3', '3', '3', '3', '3', '3', '3');
